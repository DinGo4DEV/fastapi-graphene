import setuptools
CLIENT_VERSION = "0.3.0"
PACKAGE_NAME = "graphene-pydantic"

REQUIRES = ['pydantic>=1.9','graphene>=3.0b5']
setuptools.setup(name="graphene-pydantic",
      version=CLIENT_VERSION,
      description="HKET IET Modules",
      author="Stanley Law",
      author_email="stanleylaw@hket.com",
      packages=setuptools.find_packages("."),
    #   data_files=[('configs',['config.dev.yaml','config.uat.yaml']),],
      python_requires=">=3.6",
    #   include_package_data= True,
      install_requires=REQUIRES,
      keywords=["Swagger", "OpenAPI", "Kubernetes"],
      url = "https://gitea.internal.hket.com/common_lib/hket_iet-python"
    )